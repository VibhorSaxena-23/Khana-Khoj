import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';
import React from 'react';
import { View, Text } from 'react-native';
import Home from './screens/Home';
import Search from './screens/Search';
import Details from './screens/Details';
import Splash from './screens/Splash';
import LoginPage from './screens/LoginPage';
import recipebycategory from './screens/recipebycategory';

const Stack = createStackNavigator();
const AppNavigator = () => {
  return (
    <NavigationContainer>
        <Stack.Navigator>
        <Stack.Screen
          component={Splash}
          name="Splash"
          options={{headerShown: false}}
        />
        
        <Stack.Screen
          component={Home}
          name="Home"
          options={{headerShown: false}}
        />
        <Stack.Screen
          component={Search}
          name="Search"
          options={{headerShown: false}}
        />
        <Stack.Screen
          component={Details}
          name="Details"
          options={{headerShown: false}}
        />
        <Stack.Screen
          component={recipebycategory}
          name="recipebycategory"
          options={{headerShown: false}}
        />

        </Stack.Navigator>
    </NavigationContainer>
  );
};

export default AppNavigator;
