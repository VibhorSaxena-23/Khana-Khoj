import { useNavigation } from '@react-navigation/native';
import React, { useState } from 'react';
import { View, StyleSheet, TouchableOpacity, StatusBar, Image, Text } from 'react-native';
import { FlatList, TextInput } from 'react-native-gesture-handler';

const Search = () => {
  const navigation = useNavigation();
  const [search, setSearch] = useState('');
  const [recipes,setRecipes] = useState([]);


  const SearchRecipes = async () => {
    const appId = '219b3097';
    const appKey = '36923580b908386fa49e642b46580afb';

    const myHeaders = new Headers();
    myHeaders.append('accept', 'application/json');
    myHeaders.append('Accept-Language', 'en');

    const requestOptions = {
        method: 'GET',
        headers: myHeaders,
        redirect: 'follow',
    };

    const apiUrl = `https://api.edamam.com/search?q=${search}&app_id=${appId}&app_key=${appKey}`;

    try {
        const response = await fetch(apiUrl, requestOptions);
        const data = await response.json();
        console.log(data.hits);
        setRecipes(data.hits);
    } catch (error) {
        console.error('Error fetching recipes:', error);
    }
};

  return (
    <View style={styles.container}>
      <StatusBar barStyle={'dark-content'} />
      <TouchableOpacity style={styles.backbtn} onPress={() => navigation.goBack()}>
        <Image source={require('../images/back.png')} style={styles.backIcon} />
      </TouchableOpacity>
      <View style={styles.searchbox}>
        <Image source={require('../images/search2.png')} style={styles.search} />
        <TextInput
          value={search}
          onChangeText={setSearch}
          style={styles.input}
          placeholder="  search here......"
        />
        {search !== '' && (
          <TouchableOpacity style={styles.cancel} onPress={() => {setSearch('');setRecipes([])}}>
            <Image source={require('../images/cancel.png')} style={styles.cancelIcon} />
          </TouchableOpacity>
        )}
      </View>
      {search !== '' && (
      <TouchableOpacity style={styles.searchBtn} onPress={()=>{
        setRecipes([])
        SearchRecipes()
      }}>
        <Text style={{ color: 'white' }}>search</Text>
      </TouchableOpacity>
      )}

      <FlatList data={recipes} renderItem={({item,index})=>{
        return(
            <TouchableOpacity style={styles.recipeItem} onPress={()=>{
                navigation.navigate("Details",{data:item})
            }}>
                <Image source={{uri:item.recipe.image}} style={styles.itemImage} />
                <View>
                    <Text style={styles.title}>{item.recipe.label}</Text>
                    <Text style = {styles.source}>{item.recipe.source}</Text>
                </View>
            </TouchableOpacity>
        )
      }}/>
    </View>
  );
};

export default Search;

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  backbtn: {
    width: 50,
    height: 50,
    borderRadius: 25,
    backgroundColor: 'gold',
    position: 'absolute',
    top: 10,
    left: 20,
    justifyContent: 'center',
    alignItems: 'center',
  },
  backIcon: {
    width: 30,
    height: 30,
  },
  searchbox: {
    flexDirection: 'row',
    alignItems: 'center',
    width: 320,
    height: 60,
    borderRadius: 8,
    backgroundColor: 'gold',
    alignSelf: 'center',
    marginTop: 70,
  },
  search: {
    width: 24,
    height: 24,
    marginLeft: 10,
  },
  cancel: {
    width: 20,
    height: 20,
    position: 'absolute',
    right: 10,
  },
  cancelIcon: {
    width: 20,
    height: 20,
  },
  input: {
    flex: 1,
    marginLeft: 10,
  },
  searchBtn: {
    width: '40%',
    height: 50,
    backgroundColor: 'brown',
    alignSelf: 'center',
    marginTop: 20,
    borderRadius: 8,
    justifyContent: 'center',
    alignItems: 'center',
  },
  recipeItem: {
    width: "90%",
    height: 100,
    backgroundColor: 'yellow',
    alignSelf: 'center',
    marginTop: 10,
    borderRadius: 8,
    flexDirection: 'row',
    alignItems: 'center'

  },
  itemImage: {
    width: 60,
    height: 60,
    marginLeft: 10,
    borderRadius: 8
  },
  title: {
    fontSize: 20,
    width: '60%',
    fontWeight: '500',
    marginLeft: 10,
  },
  source: {
    fontSize: 16,
    width: '60%',
    fontWeight: '500',
    marginLeft: 10,
    marginTop: 10,
    color: 'brown',
  }
});
