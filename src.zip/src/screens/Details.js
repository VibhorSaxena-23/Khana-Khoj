import { useNavigation, useRoute } from '@react-navigation/native';
import React, { useState } from 'react';
import { View, Text, StyleSheet, Image } from 'react-native';
import { FlatList, TouchableOpacity } from 'react-native-gesture-handler';

const Details = () => {
    const route = useRoute();
    const [selectedTab, setSelectedTab] = useState(0);
    const navigation = useNavigation()

    return (
        <View style={styles.container}>
            <Image source={{uri: route.params.data.recipe.image}} style={styles.banner}/>
            <TouchableOpacity style={styles.backbtn} onPress={()=>{
                navigation.goBack()
            }}>
                <Image source={require('../images/back.png')} style={styles.backIcon} />
            </TouchableOpacity>
            <Text style={styles.title}>{route.params.data.recipe.label}</Text>
            <Text style={styles.source}>{"Added by: " + route.params.data.recipe.source}</Text>
            <Text style={styles.cal}>Calories: <Text style={{color: 'brown'}}>{route.params.data.recipe.calories}</Text></Text>
            <Text style={styles.cal}>Total Weights:  <Text style={{color: 'brown'}}>{route.params.data.recipe.totalWeight}</Text></Text>
            <Text style={styles.cal}>Meal Type: <Text style={{color: 'brown'}}>{route.params.data.recipe.mealType[0]}</Text></Text>
            <View>
                <FlatList 
                    data={['Cautions', 'Health', 'Ingredients', 'Diet', 'Meal Type', 'Cuisines', 'Dish Type']}
                    horizontal
                    showsHorizontalScrollIndicator={false}
                    contentContainerStyle={{marginTop: 20}}
                    renderItem={({item, index}) => {
                        return (
                            <TouchableOpacity
                                style={[styles.typeItem, {
                                    borderWidth: selectedTab === index ? 0 : 0.5,
                                    backgroundColor: selectedTab === index ? 'gold' : 'brown'
                                }]}
                                onPress={() => {
                                    setSelectedTab(index);
                                }}>
                                <Text style={{color: selectedTab === index ? 'black' : 'white'}}>{item}</Text>
                            </TouchableOpacity>
                        );
                    }}
                />
            </View>
            <FlatList 
                data={
                    selectedTab === 0 ? route.params.data.recipe.cautions :
                    selectedTab === 1 ? route.params.data.recipe.healthLabels :
                    selectedTab === 2 ? route.params.data.recipe.ingredientLines :
                    selectedTab === 3 ? route.params.data.recipe.dietLabels :
                    selectedTab === 4 ? route.params.data.recipe.mealType :
                    selectedTab === 5 ? route.params.data.recipe.cuisineType :
                    route.params.data.recipe.dishType
                }
                renderItem={({item, index}) => {
                    return (
                        <View style={styles.labels}>
                            <Text>{item}</Text>
                        </View>
                    );
                }}
            />
        </View>
    );
};

export default Details;

const styles = StyleSheet.create({
    container: {
        flex: 1,
    },
    banner: {
        width: '100%',
        height: 250,
        resizeMode: 'cover',
    },
    backbtn: {
        width: 50,
        height: 50,
        borderRadius: 25,
        backgroundColor: 'gold',
        position: 'absolute',
        top: 10,
        left: 20,
        justifyContent: 'center',
        alignItems: 'center',
    },
    backIcon: {
        width: 50,
        height: 50,
    },
    title: {
        fontSize: 30,
        fontWeight: '800',
        width: '90%',
        alignSelf: 'center',
        marginTop: 60,
        color: 'brown',
    },
    source: {
        fontSize: 20,
        fontWeight: '800',
        marginLeft: 25,
        marginTop: 10,
        color: 'gold',
    },
    typeItem: {
        paddingLeft: 20,
        paddingRight: 20,
        paddingBottom: 10,
        paddingTop: 10,
        marginLeft: 10,
        borderRadius: 8,
    },
    labels: {
        width: '90%',
        alignSelf: 'center',
        height: 50,
        borderWidth: 2,
        justifyContent: 'center',
        marginTop: 10,
        borderColor: 'brown',
        paddingLeft: 10,
    },
    cal: {
        fontSize: 15,
        fontWeight: '600',
        marginLeft: 25,
        marginTop: 10,
        color: 'orange',
    }

});
