import { useNavigation } from '@react-navigation/native';
import React, { useEffect } from 'react';
import { View, Text, Image, StyleSheet } from 'react-native';
import * as Animatable from 'react-native-animatable';

const Splash = () => {
    const navigation = useNavigation();

    useEffect(() => {
        const timer = setTimeout(() => {
            navigation.navigate("Home");
        }, 3000); 

        return () => clearTimeout(timer);
    }, []); 
    return (
        <View style={styles.container}>
            <Animatable.View 
                animation="fadeIn"
                duration={1500}
                style={styles.logoContainer}
            >
                <Animatable.Image  
                    animation="slideInUp"
                    source={require('../images/Logo.png')}
                    style={styles.logo}
                />
                <Animatable.Text animation="slideInUp" style={styles.appname}>Khana Khaoj</Animatable.Text>
            </Animatable.View>
            <Animatable.Text animation="slideInUp" style={styles.tagline}>Search Food Recipes with Health Filters</Animatable.Text>
        </View>
    );
};

export default Splash;

const styles = StyleSheet.create({
    container: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor: 'gold'
    },
    logoContainer: {
        alignItems: 'center',
    },
    logo: {
        width: 400,
        height: 400,
        resizeMode: 'contain',
    },
    appname: {
        fontSize: 40,
        fontWeight: '800',
        color: 'brown',
        marginTop: 10,
    },
    tagline: {
        position: 'absolute',
        bottom: 50,
        fontSize: 16,
        fontWeight: '600',
        color: 'black',
    }
});
