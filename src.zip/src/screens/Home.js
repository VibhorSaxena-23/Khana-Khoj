import React, { useEffect, useState } from 'react';
import { View, Text, StyleSheet, Image, StatusBar } from 'react-native';
import { FlatList, TouchableOpacity } from 'react-native-gesture-handler';
import { MEAL_FILTERS } from '../Data';
import { useNavigation } from '@react-navigation/native';


const Home = () => {
    const navigation = useNavigation()
    const [recipes, setRecipes] = useState([]);

    useEffect(() => {
        getTrendyRecipes();
    }, []);

    const getTrendyRecipes = async () => {
        const appId = '219b3097';
        const appKey = '36923580b908386fa49e642b46580afb';

        const myHeaders = new Headers();
        myHeaders.append('accept', 'application/json');
        myHeaders.append('Accept-Language', 'en');

        const requestOptions = {
            method: 'GET',
            headers: myHeaders,
            redirect: 'follow',
        };

        const apiUrl = `https://api.edamam.com/search?q=food&app_id=${appId}&app_key=${appKey}`;

        try {
            const response = await fetch(apiUrl, requestOptions);
            const data = await response.json();
            console.log(data.hits);
            setRecipes(data.hits);
        } catch (error) {
            console.error('Error fetching recipes:', error);
        }
    };

    return (
        <View style={styles.container}>
            <StatusBar barStyle='light-content' />
            <View style={styles.topView}>
                <Image source={require('../images/banner2.jpeg')} style={styles.banner} />
                <View style={styles.transparentView}>
                    <Text style={styles.brand}>Khana Khoj</Text>
                    <TouchableOpacity style={styles.SearchBox} 
                    onPress={()=>{
                        navigation.navigate('Search')
                    }}>
                        <Image source={require('../images/search2.png')} style={styles.search} />
                        <Text style={styles.placeholder}>Please search here .......</Text>
                    </TouchableOpacity>
                    <Text style={styles.note}>Search 1000+ recipes with one click</Text>
                </View>
            </View>
            <Text style={styles.heading}>Categories</Text>
            <View>
                <FlatList
                    horizontal
                    data={MEAL_FILTERS}
                    showsHorizontalScrollIndicator={false}
                    renderItem={({ item, index }) => {
                        return (
                            <TouchableOpacity activeOpacity={0.8} style={styles.categoryItem} onPress={()=>{
                                navigation.navigate("recipebycategory",{
                                    data:item.title
                                })
                            }}>
                                <View style={styles.card}>
                                    <Image source={item.icon} style={styles.categoryIcon} />
                                </View>
                                <Text style={styles.category}>{item.title}</Text>
                            </TouchableOpacity>
                        );
                    }}
                />
            </View>
            <Text style={styles.heading}>Trendy Recipes</Text>
            <View>
                <FlatList showsHorizontalScrollIndicator={false} contentContainerStyle={{marginTop: 20}} horizontal data={recipes} renderItem={({item,index})=>{
                    return(<TouchableOpacity style={styles.recipesItems}
                    onPress={()=>{
                        navigation.navigate("Details",{
                            data: item,
                        })
                    }}
                    >
                        <Image source={{uri:item.recipe.image}} style = {styles.recipeImage} />
                        <View style={[styles.transparentView,{borderRadius:15}]}>
                        <Text style={styles.recipeLabel}>{item.recipe.label}</Text>
                        </View>
                    </TouchableOpacity>)
                }} />
            </View>
        </View>
    );
};

export default Home;




const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  topView: {
    width: '100%',
    height: '40%'
  },
  banner: {
    width: '100%',
    height: '100%'
  },
  transparentView: {
    position: 'absolute',
    width: '100%',
    height: '100%',
    backgroundColor: 'rgba(0,0,0,0.6)', 
    justifyContent: 'center',
    alignItems: 'center'
  },
  SearchBox: {
    width: 390,
    height: 60,
    borderRadius: 8,
    backgroundColor: 'gold',
    flexDirection: 'row',
    alignItems: 'center',
    paddingLeft: 10
  },
  search: {
    width: 24,
    height: 24
  },
  placeholder: {
    marginLeft: 15,
    fontSize: 16,
    color: 'brown'
  },
  brand: {
    fontSize: 40,
    color: 'gold',
    position: 'absolute',
    top: 60,
    left: 20,
  },
  note: {
    fontSize: 16,
    color: 'rgba(255, 215, 0, 0.8)',
    width: '90%',
    alignSelf: 'center',
    textAlign: 'center',
  },
  heading: {
    fontSize: 25,
    color:'brown',
    fontWeight: 'bold', 
    marginLeft: 20,
    marginTop: 20,
  },
  categoryItem: {
    width: 150,
    height: 150, 
    justifyContent: 'center',
    alignItems: 'center'
    /*backgroundColor: 'gold', 
    borderRadius: 8,
    shadowColor: 'rgba(0,0,0,.3)',
    shadowOpacity: 6,
    margin: 10,*/
  },
  card: {
    width: '80%',
    height: '70%',
    backgroundColor: 'gold', 
    borderRadius: 8,
    shadowColor: 'rgba(0,0,0,.3)',
    shadowOpacity: 6,
    alignItems: 'center'
  },
  categoryIcon:{
    width: 120,
    height: 100,
  },
  category: {
    fontSize:18 ,
    color:'brown',
    fontWeight:'bold' ,
    alignSelf: 'center',
    marginTop: 10,
  },
  recipesItems: {
    width: 150,height: 200,
    marginLeft: 20,
    borderRadius: 10,
  },
  recipeImage: {
    width: '100%',
    height: '100%',
    borderRadius: 10,
  },
  recipeLabel: {
    color: 'gold',
    fontSize:15,
    fontWeight: '600'
  }
});
